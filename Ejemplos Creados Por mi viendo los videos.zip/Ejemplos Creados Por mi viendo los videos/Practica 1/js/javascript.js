var nombre=prompt ('¿Como te llamas?');
var pais = prompt ('¿De donde eres?');
alert("Bienvenido" + nombre + "de" + pais);


var modelo = 'Mustang'
	 console.log(modelo);
	 var auto = {
		 nombre: 'Mustang',
		 motor: 5.5,
		 color: 'azul',
		 año: 1965,
		 clasico: true
	 }
	 console.log(auto.nombre);
	 console.log(auto.motor);
	 console.log(auto.color);
	 console.log(auto.año);
	 console.log(auto.clasico);




var premierleague = ["Chelsea", "Mancheter United", "Liverpool", "Arsenal"];
 console.log(premierleague);

	 premierleague.push("Mancheter City");
	 console.log(premierleague);

	 premierleague[2]= "Leicester";
	 console.log(premierleague.indexOf("Mancheter United"));

	 var liga = new Array("Chelsea", "Mancheter United", "Liverpool", "Arsenal");
 	console.log("Liga de Futbol", liga.reverse());
 	liga.pop();
    console.log(liga);
    liga.splice("Con splice " + 1,2);
	 console.log(liga);
	 

var numero1="15";
var numero2=-20;
var numero3=21.5;
var numero4=20;
var numero5="3.1416";

console.log(typeof(numero1));
console.log(typeof(numero2));
console.log(typeof(numero3));
console.log(typeof(numero4));
console.log(typeof(numero5));

console.log(parseInt(numero1) + 20);

var numero6=parseFloat(numero5);
console.log((numero6+20).toFixed(2));



var fecha =new Date();
console.log(fecha);
console.log("El año es: "+ fecha.getFullYear());
console.log("El Dia es: "+fecha.getDate());
console.log("El mes es: "+ fecha.getMonth());
console.log("El año de la semana actual es: "+ fecha.getDay());
console.log("La hora actual es: "+ fecha.getHours());
console.log("Los minutos transcurridos son: "+fecha.getMinutes());


var texto=("Esto es un texto en una cadena de texto");
console.log(texto);
console.log(typeof(texto));                  //Identifica el tipo de varible, en este caso String o Cadena
console.log(texto.toUpperCase());            //Cambia las Propiedades de la cadena para establecer en letra mayuscula
console.log(texto.length);                   //Arroja el tamaño de la cadena (Contado los espacios en blanco)
console.log(texto.split(" "));                     //Divide la cadena a partir de que encuetre lo que se le declare, en este caso spara el texto cada que encuentre un espacio en blanco
console.log(texto.indexOf("Cadena"));        //Cuenta el numero de caracteres hasta llegar a la palabra cadena
console.log(texto.slice(0,11));              //Solo imprime todo lo que e encuentre del primer caracter al numero 11, lo demas no lo imprime
console.log(texto.toLocaleLowerCase());      //pasa toda la cadena a letr minuscula




	  	
 //Encontrar el numnero 5 en alaeatorio de 1 al 10
 var vector = [];
 for (var i=0; i<10; i++){
    var aleatorio = Math.round(Math.random()*10);
    vector[i]=aleatorio;
    console.log(aleatorio);
    if (aleatorio==5) console.log("Encontre el numero 5");
 }

 /*ejemplos de if, else , ifelse*/
 var cantidadPagar = 100;
 var saldo = 500;
 if (saldo <cantidadPagar) {
	 console.log("No hay saldo para pagar");
 } else if(saldo == cantidadPagar) {
	 console.log("Son iguales");

 }else{
	 console.log("El pago se realizo con exito");
 }
 
 //AND //
 var cantidadPagar = 100;
 var saldo = 500;
 var recargaCel = 10;
 var usuarioValido= false;

 if (saldo > cantidadPagar && usuarioValido) {
	 console.log("Se pago correctamente");
 } else{
	 console.log("No se pudo pagar");
 }
 // OR//
 var cantidadPagar = 100;
 var efectivo = 500;
 var recargaCel = 10;
 var tarjetaDeCredito= true;

 if (efectivo > cantidadPagar || usuarioValido) {
	 console.log(" pago realizado");
 } else{
	 console.log("No se pudo pagar");
 }

 // Switch//
 var metodoDePago= "vales";
 var metodo1 = "efectivo";
 var metodo2 = "cheque";
 var metodo3 = "paypal";
 var metodo4 = "vales";

 switch(metodoDePago){
	 case "efectivo":
	 console.log("se pago con tarjeta de redito");
	 break;
	 case "cheque":
	 console.log("se pago con cheque");
	 break;
	 case "vales":
	 console.log("se pago con tarjeta de vales");
	 break;
	 default:
	 console.log("metodo de pago no valido");
	 break;
 }

 //while Y Do While//
 var i=0;
 while (i<10) {
	 console.log(i)
	 i++;
	}

var contar =0;
do{
	console.log(contar + "veces es igual a"+ contar * 7);
}while (contar++ <8); {
	
}
/*aleatorio de un arreglo de 10 numeros enteros positivo 1 y 100 y que posteriomente determine el numero mayor y el numero mayor del arreglo*/
var vec = new Array(10), mayor, menor;
vec = [32,5,87,55,12,5,23,0,65,17]
mayor = vec[0];
menor = vec[0];
console.log("vector Condatos: ", vec, "\n\n");
for (var i = 0; i<10;i++){
	if (vec[i] > mayor){
		mayor = vec [i];
	}
	if (vec[i]<menor){
		menor = vec[i];
	}
}
console.log("El mayor del vector es: " ,mayor, "El menor vector es: " ,menor);
// Ddiagonal principal y secundariai//
var mat1=[[1,2,3,4],[2,4,6,8],[1,3,6,9],[0,3,5,7]];
for (var i=0;i<4; i++){
	mat1[i][4-1-i]=1;
}
for (var i = 0; i <4; i++) {
	for (var j= 0; j< 4; j++) {
		console.log(mat1[i][j]);
	}
}


//ar
var array1=new Array(1,2,3,4,5,6);
var array2=new Array(2,4,6,7,8);
console.log(array1,array2);
var iguales=[];

for(var i=0;i<array1.length;i++)
{
	for(var j=0;j<array1.length;j++)
	{
		if(array1[i]==array2[j])
			iguales++;
	}
}
	console.log(iguales);
	console.log(Array[iguales]);


	//
var a = "1,3,6,9,10,12",
    b = "0,2,4,6,8,10",
    ax = a.split(" "),
    bx = b.split(" "),
    c = [];
    
ax.forEach(function(w){
    if (b.indexOf(w)< 0){
        c.push(w);
    }
});
 
bx.forEach(function(w){
    if (a.indexOf(w) < 0){
        c.push(w);
	}
	
});
 
console.log(c.join(""));

function Hacer_Click(){
	alert("Hemos enviado el mensaje")
    location.reload();
}

///fgg
function miFuncion()
{
	var nom= null;
	var nacio=0;
	nom=document.getElementsByName("nombre")[0].value;
	nacio=document.getElementsByName("nacido")[0].value;

	if(nom.length<=0){
		alert("Teclee el nombre de la persona");
		return;

	}
	if (nacio<=0){
		alert("Teclee un año de nacimiento");
		return;

	}
	var fecha= new Date();
	var aa = fecha.getFullYear();
	var edad=aa-nacio;
	edad = edad + "Años";

	document.getElementById("nombre").innerHTML = nom;
	document.getElementById("edad").innerHTML = edad;
	

}
function Otras(){
	var Nombre= null;
	var Telefono= null;
	var Direccion= null;
	
	Nombre=document.getElementsByName("Nombre")[0].value;
	Telefono=document.getElementsByName("Telefono")[0].value;
	Direccion=document.getElementsByName("Direccion")[0].value;
	if(Nombre.length<=0){
		alert("Teclee el nombre de la persona");
		return;

	}
	
	if(Telefono.length<=0){
		alert("Teclee el Numero Telefonico");
		return;

	}
	
	if(Direccion.length<=0){
		alert("Teclee La direccion");
		return;

	}
	document.getElementById("Nombre").innerHTML = Nombre;
	document.getElementById("Telefono").innerHTML = Telefono;
	document.getElementById("Direccion").innerHTML = Direccion;

}

