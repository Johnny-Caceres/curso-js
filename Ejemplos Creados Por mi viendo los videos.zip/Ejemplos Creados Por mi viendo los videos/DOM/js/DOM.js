//DOM getElementById//
(function(){
'use strict';
document.addEventListener('DOMContentLoaded', function(){
document.getElementById('logo');
}

)
// DOM getElementsByClassName

var navegacion= document.getElementsByClassName("navegacion");
console.log(navegacion);


// DOM getElementsByTagName
var enlaces = document.getElementsByTagName("a");
console.log(enlaces);

// DOM Query Selector

var logo = document.querySelector("#logo2");
console.log(logo2);

var encabezado = document.querySelector("anside h2 ");
Console.log(encabezado);

//DOM Query Selector All
var encabezado = document.querySelectorAll("h2 footer  ");
Console.log(encabezado);

var enlaces = document.querySelectorAll("p");

for (var i=a; i=enlaces.length; i++){
console.log(enlaces[i].innerText);
}

////DOM Query Selector All (nodos)
var  enlances = document.querySelectorAll("#menu  ul li p")[0];
console.log(enlaces.nodeType);
console.log(enlaces.nodeName);
console.log(enlances.attributes);
console.log(enlaces.firstChild);
console.log(enlaces.firstChild.nodeValue);

enlaces.firstChild.nodeType="Home";

var  enlances = document.querySelectorAll("#menu  ul li p")[0];
console.log(enlaces.nodeType);
console.log(enlaces.nodeName);
console.log(enlances.attributes);
console.log(enlaces.firstChild);
console.log(enlaces.firstChild.nodeValue);

enlaces.firstChild.nodeType="Home";

//DOM Creando Elementos
var sidebar=document.querySelector("#sidebar");
var nuevoElemento= document.createElement("h1");
var nuevoTexto=document.createTextNode("Hola mundo");

nuevoElemento.appendChild(nuevoTexto);
sidebar.appendChild(nuevoElemento);


// DOM Clonando Elemntos

var contenido=document.querySelectorAll("main");
var nuevoContenido= contenido[0].cloneNode(true);

var sidebar = document.querySelector("aside");
sidebar.insertBefore(nuevoContenido,sidebar.childNodes[5]);

//DOM Control de Inserciones con inserbefore

var sidebar=document.querySelector("aside");

var masVisitados= document.createElement("h2");
var textoVisitados= document.createElement("Mas Visitados");
masVisitados.appendChild(textoVisitados);
sidebar.insertBefore(masVisitados, sidebar.childNodes[0]); 

var contenido= document.querySelectorAll("main h2")
for(var i=0; i<contenido.length; i++){
	var nuevoElemento=document.createElement("li");
	var nuevoTexto=document.createTextNode(contenido[i].firstChild.nodeValue);
	nuevoElemento.appendChild(nuevoTexto);
	sidebar.insertBefore(nuevoElemento, sidebar.childNodes[1]);


}
