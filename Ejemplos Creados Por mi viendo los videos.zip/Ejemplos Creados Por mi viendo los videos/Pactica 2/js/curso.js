function funcion() {
    var elemento;
    elemento = document.getElementById("elElemento")
    elemento.onclick = otra_funcion; 
    }
     
    function otra_funcion(){
    alert("Capturado");
    }
     
    <body onload = "funcion();">