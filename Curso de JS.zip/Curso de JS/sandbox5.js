//const para = document.querySelector('body > h1');
//console.log(para);

//const paras = document.querySelectorAll('p');
//paras.array.forEach(para => {
//    console.log(paras)
    
//});
//console.log(paras[2]);

//const paras = document.querySelectorAll('p');
//const errors = document.querySelectorAll('.error');

//console.log(errors);


//get an element by ID
//const title = document.getElementById('page-title');
//console.log(title);

//get elements by their class name
//const errors = document.getElementsByClassName('error');
//console.log(error);
//console.log(errors[0]);

//get elements by their tag name
//const paras = document.getElementsByTagName('p');
//console.log(paras);
//console.log(paras[1]);

const para = document.querySelector('p');
//console.log(para.innerText);
//para.innerText='ninjas are awesome!';

const paras = document.querySelectorAll('p');
//paras.forEach(para =>{
//    console.log(para.innerText);
//    para.innerText += 'new text';
//});

const content = document.querySelector('.content');
//console.log(content.innerHTML);
//content.innerHTML += '<h2>this is a mew h2</h2>';

const people =['mario','luigi','yoshi'];

people.forEach(person =>{
    content.innerHTML +=`<p>${person}</p>`;
});


/////////////////////////////////////
const link = document.querySelector('a');
console.log(link.getAttribute('href'));
link.setAttribute('href','http://www.theretninja.co.uk');
link.innerText= 'the Net ninja Website';
const mssg = document.querySelector('p');

console.log(mssg.getAttribute('class'));
mssg.setAttribute('class', 'success');
mssg.setAttribute('style','color: green;');

/////////////////////////////////////////

const title=document.querySelector('h1');

//title.setAttribute('style','margin:50px;');
console.log(title.style);
console.log(title.style.color);
title.style.margin='50';
title.style.color='crimson';
title.style.fontSize='60px';


